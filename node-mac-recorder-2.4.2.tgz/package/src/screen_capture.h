#ifndef SCREEN_CAPTURE_H
#define SCREEN_CAPTURE_H

#import <Foundation/Foundation.h>
#import <CoreGraphics/CoreGraphics.h>
#import <napi.h>

@interface ScreenCapture : NSObject

+ (NSArray *)getAvailableDisplays;
+ (BOOL)captureDisplay:(CGDirectDisplayID)displayID 
                toFile:(NSString *)filePath 
                  rect:(CGRect)rect
           includeCursor:(BOOL)includeCursor;
+ (CGImageRef)createScreenshotFromDisplay:(CGDirectDisplayID)displayID 
                                     rect:(CGRect)rect;

@end

// NAPI function declarations for legacy fallback
Napi::Value GetAvailableDisplays(const Napi::CallbackInfo& info);
Napi::Value GetWindowList(const Napi::CallbackInfo& info);

#endif // SCREEN_CAPTURE_H 